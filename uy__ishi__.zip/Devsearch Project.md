# "*Devsearch*" loyihasi

1. User avtorizatsiya/autentifikatsiya
2. Parolni o'zgartirish/tiklash
3. Profilni boshqarish
4. Shaxsiy akkauntni sozlash
5. Loyihalarni ko'rish
6. Shaxsiy loyiha qo'shish va boshqarish
7. Barcha loyihalarni ko'rish va kommentariya yozish
8. Boshqa dasturchilarga xabar yozish va bog'lanish (SMS quti)
9. Dasturchilarni qidirish
10. Loyihalarni ishlatilgan texnologiyalar bo'yicha qidirish

## Ishlatiladigan texnologiyalar:
1. Python
2. JavaScript
3. Django
4. Django Rest Framework
5. HTML
6. CSS
7. Nginx
8. Gunicorn
9. PostgreSQL / MySQL
10. Linux OS
11. Cloudinary
